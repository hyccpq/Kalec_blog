export const userInfo = {
    user: 'hyccpq',
    email: 'hyccpq@hotmail.com',
    password: '3diansan',
    role: 'admin'
}

export const secret = 'HyccpqHYC3jkl'
