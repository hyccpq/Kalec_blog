# Kalec_blog
Welcome to my blog!

> 从12月份开始，经历了不少的折腾。现在终于是上线了，spa的体验简直不错！不过由于自己水平的问题，~加上没有做ssr服务端渲染~，，~特别移动端的体检简直渣到爆~。

后台已完成ssr渲染

前台用到的技术栈：vue+vuex+axios+stylus

后台用到的技术栈：koa2+MongoDB

其他：网络传输用了HTTP2协议

展示地址：[冰空的作品展示](https://www.kalecgos.top)
