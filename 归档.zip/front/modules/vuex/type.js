export const SET_TOKEN = 'set_token';
export const LOG_OUT = 'log_out';
export const GET_LIST = 'get_list';
export const GET_ARTICLE_INFO = 'get_article_detail_info';
export const GET_ALL_TAG_CLASSIC = 'get_all_tag_classic'
export const UPDATE_SCROLL_TOP = 'update_scroll_top'
export const SHOW_LOADING = 'show_loading'
