<template>

</template>

<script>
	export default {
		name: "aboutme"
	}
</script>

<style scoped>

</style>
